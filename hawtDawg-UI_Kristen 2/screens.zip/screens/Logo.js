import React, { Component } from 'react'
import { Image } from 'react-native'

const logo = () => (
   <Image source = {require('../assets/images/logo.png')} />
)
export default logo